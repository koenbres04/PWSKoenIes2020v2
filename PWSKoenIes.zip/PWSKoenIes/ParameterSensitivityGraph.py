from ModelMain import Model, s_squared


def export_local_parameter_space(model: Model, data, parameter_name, parameters, num_subdivisions, radius):
    pass
